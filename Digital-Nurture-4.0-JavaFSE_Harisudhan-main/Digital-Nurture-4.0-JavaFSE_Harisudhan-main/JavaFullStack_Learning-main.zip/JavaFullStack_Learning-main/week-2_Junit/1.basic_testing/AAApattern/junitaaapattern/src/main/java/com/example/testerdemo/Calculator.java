package com.example.testerdemo;

public class Calculator {
    public Calculator(){}

    public int add(int a , int b){
        return a+b;
    }
    public int sub(int a , int b){
        return a-b;
    }
    public int prod(int a , int b){
        return a*b;
    }
    public int div(int a , int b){
        return (int)a/b;
    }
    
}
