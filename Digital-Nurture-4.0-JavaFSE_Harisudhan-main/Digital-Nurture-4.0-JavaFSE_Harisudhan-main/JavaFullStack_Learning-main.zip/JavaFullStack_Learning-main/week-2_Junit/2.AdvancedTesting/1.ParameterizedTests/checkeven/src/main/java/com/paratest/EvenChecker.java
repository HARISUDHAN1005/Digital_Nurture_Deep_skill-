package com.paratest;

public class EvenChecker {
    public boolean isEven(int n){
        return (n%2)==0 ;
    }
}
