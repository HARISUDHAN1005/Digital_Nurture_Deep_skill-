package main;
public class PdfDocument implements Document {
    public void read(){
        System.out.println("Reading pdf document");
    }
}
