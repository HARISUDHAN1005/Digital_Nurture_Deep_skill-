package main;
public class WordDocument implements Document{
   public  void read(){
        System.out.println("Reading a word document");
    }
}
