package main;
public class TextDocument implements Document{
    public void read(){
        System.out.println("Reading a text document");
    }
}
