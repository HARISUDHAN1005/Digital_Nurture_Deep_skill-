package main;
public interface Document {
    void read();
}
