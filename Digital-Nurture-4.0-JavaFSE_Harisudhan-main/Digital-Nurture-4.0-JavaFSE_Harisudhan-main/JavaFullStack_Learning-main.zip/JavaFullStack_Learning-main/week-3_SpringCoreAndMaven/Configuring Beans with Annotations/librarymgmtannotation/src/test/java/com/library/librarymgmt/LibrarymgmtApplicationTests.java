package com.library.librarymgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarymgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
