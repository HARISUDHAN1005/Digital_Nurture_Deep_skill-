package com.library.librarymgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrarymgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrarymgmtApplication.class, args);
	}
}
