package com.springjpa.implservices;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImplservicesApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
