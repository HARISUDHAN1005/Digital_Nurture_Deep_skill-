package com.mockdemo;

public interface ExternalApi {
    String fetchData (String endPoint);
}
